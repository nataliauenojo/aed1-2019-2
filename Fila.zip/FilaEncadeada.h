#include <stdio.h>
#include <stdlib.h>



typedef enum boolean{false=0, true=1} Boolean;
typedef int Tipo;

/**
 * Registro utilizado para acomodar cada elemento da pilha (Nó).
 */
typedef struct no{
    Tipo dado;
    struct no* prox;
}No;

/**
 * Estrutura usada para representar e armazenar a FILA com alocação encadeada.
 */
typedef struct{
    No* prim;
    No* ult;
    int qtde;
}Fila;


Fila* fila_criar(){
    Fila* f=(Fila*)malloc(sizeof(Fila));
    f->qtde=0;
    return f;
}

void fila_destruir(Fila* f){
    No* aux;
    if(f->prim!=NULL){
        aux=f->prim;
        f->prim=aux->prox;
        free(aux);
    }
    free(f);
}

Boolean fila_inserir(Fila* f, Tipo elemento){
    No*aux;//para não perder os dados da fila original
    No*novo=(No*)malloc(sizeof(No));//armazenar o elemento
    novo->dado=elemento;
    if(f->ult==NULL){
        f->ult=novo;
        f->qtde++;
    }else{
        aux=f->ult;//armazenar o valor do ultimo elemento da fila
        f->ult=novo;
        aux->prox=f->ult;
        f->qtde++;
    }
}

Tipo* fila_remover1(Fila* f){
    if(f->prim==NULL)return NULL;
    Tipo*endereco=(Tipo*)malloc(sizeof(Tipo));
    fila_remover2(f,endereco);
    return endereco;
}

Boolean fila_remover2(Fila* f, Tipo* endereco){
    if(f->primeiro==NULL)return false;
    No* aux;
    aux=p->ult;
    p->ult=(p->ult)-1;
    *endereco=aux->dado;
    free(aux);
    p->qtde--;
    return 1;
}

Boolean fila_primeiro(Fila* f, Tipo* endereco){
    if(f->prim==NULL)return false;
    Tipo*endereco=(Tipo*)malloc(sizeof(Tipo));
    No*aux;
    aux=f->prim;
    *endereco=aux->dado;
    return endereco;
}

int fila_tamanho(Fila* f){
    if(f->prim==NULL)return 0;
    No*aux;
    int tam=0;
    while(f->prim!=NULL){
        aux=f->prim;
        f->prim=f->prim->prox;
        tam++;
    }
    return 1;
}

int fila_contem(Fila* f, Tipo elemento){
    if(f->prim==NULL)return 0;
    No* aux;
    while (f->prim!=NULL){
        aux=f->prim;
        if (aux->dado==(*elemento)){
            return 1;
        }
        else{
            p->prim=p->prim->prox;
        }
    }
}
void fila_imprimir(Fila* f){
    if(f->prim==NULL)return 0;
    No*aux;
    while(f->prim!=NULL){
        aux=f->prim;
        printf("%d",aux->dado);
        f->prim=f->prim->prox;
    }
}