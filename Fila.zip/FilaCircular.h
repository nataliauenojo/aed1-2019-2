
#include <stdio.h>
#include <stdlib.h>


typedef enum boolean{false=0, true=1} Boolean;
typedef int Tipo;

typedef struct{
    Tipo* vetor;
    int tam;
    int inicio;
    int fim;
}Fila;


Fila* fila_criar(){
    Fila*f=(Fila*)malloc(sizeof(Fila));
    f->tam=0;
    return f;
}

void fila_destruir(Fila* f){
    if(f->vetor==NULL)return NULL;
    free(f->vetor);
}

Boolean fila_inserir(Fila* f, Tipo elemento){
    Tipo*aux;
    Tipo*novo=(Tipo*)malloc(sizeof(Tipo));
    novo->dado=elemento;
    if(f->ultimo==NULL){
        f->ultimo=novo;
        f->tam++;
    }else{
        for(int i=0;i<p->tam;i++){
            aux=f->vetor;
        }
        f->tam++;
        for(int i=0;i<f->tamt;i++){
            if(i<f->tam){
                f->vetor=aux;
            }
            else{
                f->vetor=novo->dado;
                novo->dado=f->ultimo;
            }
        }
    }
    free(aux);
    return true;
}

Tipo* fila_remover1(Fila* f){
    if(f->primeiro==NULL)return NULL;
    Tipo*endereco=(Tipo*)malloc(sizeof(Tipo));
    fila_remover2(f,endereco);
    return endereco;
}

Boolean fila_remover2(Fila* f, Tipo* endereco){
    if(f->vetor==NULL)return 0;
    Tipo* aux;
    for(int i=0;i<tam;i++){
        aux=f->vetor;
        if(i=(tam-1)){
            *endereco=aux;
        }
    }
    f->tam--;
    for (int j = 0; j < tam; j++){
        f->vetor=aux; 
    }
    return 1;
}

Boolean fila_primeiro(Fila* f, Tipo* endereco){
    if(f->primeiro==NULL)return false;
    Tipo*endereco=(Tipo*)malloc(sizeof(Tipo));
    *endereco=f->primeiro;
    return endereco;
}

int fila_tamanho(Fila* f){
    if(f->primeiro==NULL)return 0;
    Tipo*aux;
    int tam1=0;
    for(int i=0;i<tam;i++){
        tam++;
    }
    return 1;
}

int fila_contem(Fila* f, Tipo elemento){
    if(f->vetor==NULL)return 0;
    for (int i=0; i<f->tam;i++){
        if (f->vetor==elemento){
            return 1;
        }
    }
}
void fila_imprimir(Fila* f){
    if(f->vetor==NULL)return 0;
    for (int i=0; i<f->tamanhoVet;i++){
        printf("%d ",f->vetor);
    }
}