
#include <stdlib.h>
typedef struct
{
    int **m;
    //  int* m;
    int linhas;
    int colunas;
} Matriz;

Matriz *matriz_cria(int linhas, int colunas);
void matriz_atribui(Matriz *m, int lin, int col, int valor);
int matriz_acessa1(Matriz *m, int lin, int col);
void matriz_acessa2(Matriz *m, int lin, int col, int *end);
void matriz_imprime(Matriz *m);
void matriz_destroi(Matriz *m);

Matriz *matriz_cria(int linhas, int colunas)
{
    Matriz *mat = (Matriz *)malloc(sizeof(Matriz));
    mat->m = (int **)calloc(linhas, sizeof(int *));
    int i;
    for (i = 0; i < linhas; i++)
    {
        mat->m[i] = (int *)calloc(colunas, sizeof(int));
    }
}

void matriz_imprime(Matriz *m)
{
}
