
#include <stdlib.h>
#include <stdio.h>
typedef struct
{
    int **m;
    //  int* m;
    int linhas;
    int colunas;
} Matriz;

Matriz *matriz_cria(int linhas, int colunas);
void matriz_atribui(Matriz *m, int lin, int col, int valor);
int matriz_acessa1(Matriz *m, int lin, int col);
void matriz_acessa2(Matriz *m, int lin, int col, int *end);
void matriz_imprime(Matriz *m);
void matriz_destroi(Matriz *m);

Matriz *matriz_cria(int linhas, int colunas){
    Matriz *mat = (Matriz *)malloc(sizeof(Matriz));
    mat->m = (int **)calloc(linhas, sizeof(int *));
    int i;
    for (i = 0; i < linhas; i++)
    {
        mat->m[i] = (int *)calloc(colunas, sizeof(int));
    }
    mat->linhas = linhas;
    (*mat).colunas = colunas;

    return mat;
}

void matriz_atribui(Matriz *m, int lin, int col, int valor){
    for(int i =0;i<m->linhas;i++){
        for (int j = 0; j < m->colunas; j++){
            if(m->linhas==lin && m->colunas==col){
                m->m[i][j]=valor;
            }
        }
    }
}

int matriz_acessa1(Matriz *m, int lin, int col){
    for (int i = 0; i < m->linhas; i++){
        for (int j = 0; j < m->colunas; j++){
            if(m->colunas==col && m->linhas==lin){
                return 1;
            }
        }        
    }
    return 0;   
}

void matriz_acessa2(Matriz *m, int lin, int col, int *end){
    for (int i = 0; i < m->linhas; i++){
        for (int j = 0; j < m->colunas; j++){
            if(m->colunas==col && m->linhas==lin){
                return *end;
            }
        }        
    }
}

void matriz_destroi(Matriz *m){
    int *aux;
    for(int i =0;i<m->linhas;i++){
       for(int j=0;j<m->colunas;j++){
           m->m[i][j]=*aux;
           free(aux);
       }
   }
   free(m);
   free(m);
}



void matriz_imprime(Matriz *m){
   for(int i =0;i<m->linhas;i++){
       for(int j=0;j<m->colunas;j++){
           printf("%d ",m->m[i][j]);
       }
   }
}

