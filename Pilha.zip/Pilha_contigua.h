#include <stdio.h>
#include <stdlib.h>

typedef enum boolean{false=0, true=1} Boolean;
typedef int Tipo;

typedef struct{
    int* vetor;
    int tam;
    int qtde;
}Pilha;

//Prototipos
Pilha* pilha_criar();
Boolean pilha_push(Pilha* p, int elemento);
int* pilha_pop1(Pilha* p);
Boolean pilha_pop2(Pilha* p, int* end);
void pilha_destruir(Pilha* p);
void pilha_imprimir(Pilha* p);
int pilha_posicao(Pilha* p, int elemento);
int pilha_tamanho(Pilha* p);
//FUNÇÕES ADICIONAIS
int pilha_pushAll(Pilha* p, int* vetor, int tam);
void pilha_inverter(Pilha* p);
Pilha* pilha_clone(Pilha* p);

//Implementação

Pilha* pilha_criar(){
    Pilha* p=(Pilha*)malloc(sizeof(Pilha));
    p->vetor=(int*)calloc(p->tam,sizeof(int));
    p->qtde=0;
}

Boolean pilha_push(Pilha* p, int elemento){
    Tipo* aux;
    if(p->vetor==NULL){
        p->vetor=elemento;
        p->tam++;
        return true;
    }else{
        for(int i=0;i<p->tam;i++){
            aux=p->vetor;
        }
        p->tam++;
        if(aux==p->vetor){
            p->vetor=aux;
        }else{
            p->vetor=elemento;
            return true;
        }
    }
    return false;
}

int* pilha_pop1(Pilha* p);
Boolean pilha_pop2(Pilha* p, int* end){
    if (p->vetor==NULL)return false;
    Tipo* aux;
    for(int i=0;i<p->tam;i++){
        aux=p->vetor;
        if(i==0){
            *endereco=aux->vetor;
        }
        p->vetor=aux+1;
    }
    free(aux);
    p->tamVetor--;
    return true;
}

void pilha_destruir(Pilha* p){
    if(p->vetor==NULL)return 0;
    free(p->vetor);
}

void pilha_imprimir(Pilha* p){
    for(int i=0;i<p->tam;i++){
        printf("%d\n",p->vetor);
    }
}

int pilha_posicao(Pilha* p, int elemento){
    int posicao=0;
    for(int i=0;i<p->tam;i++){
        if(p->vetor==elemento){
            posicao=i;
            return posicao;
        }
    }

}

int pilha_tamanho(Pilha* p){
    int tam=0;
    for(int i=0;i<p->tam;i++){
        tam++;
    }
    return tam;
}
