#include <stdio.h>
#include <stdlib.h>



typedef enum boolean{false=0, true=1} Boolean;

/**
 * Registro utilizado para acomodar cada elemento da pilha (Nó).
 */
typedef struct no{
    int dado;
    struct no* prox;
}No;



/**
 * Estrutura usada para representar e armazenar a PILHA com alocação encadeada.
 */
typedef struct{
    No* topo;
    int qtde;
}Pilha;

Pilha* pilha_criar();
Boolean pilha_push(Pilha* p, int elemento);
int* pilha_pop1(Pilha* p);
Boolean pilha_pop2(Pilha* p, int* end);
void pilha_destruir(Pilha* p);
void pilha_imprimir(Pilha* p);
int pilha_posicao(Pilha* p, int elemento);
int pilha_tamanho(Pilha* p);
int pilha_pushAll(Pilha* p, int* vetor, int tam);
void pilha_inverter(Pilha* p);

Pilha* pilha_clone(Pilha* p){
   Pilha*clone=(Pilha*)malloc(sizeof(Pilha));
   while(p->topo!=NULL) {
     clone=p;
   }
   return clone
}

Pilha* pilha_criar(){
  Pilha*p=(Pilha*)malloc(sizeof(Pilha));//criar pilha
  p->qtde=0;//zerar a quantidade
  return p;
}


void pilha_destruir(Pilha* p){
  No*aux;//criar uma auxiliar
  while(p->topo!=NULL){
      aux=p->topo;//auxiliar recebe topo
      p->topo=aux->prox;// topo recebe a proxima posiçao
      free(aux);//limpar o no
  }
  free(p);//limpar a pilha
}

Boolean pilha_push(Pilha* p, int elemento){
  No*aux;
  No*novo=(No*)malloc(sizeof(No));
  novo->dado=elemento;
  if(p->topo==NULL){
      p->topo=novo;
      p->qtde++;
      return true;
  }
  else{
      aux=p->topo;
      p->topo=novo;
      novo->prox=aux;
      p->qtde++;
      return true;
  }
  return false;
}

int* pilha_pop1(Pilha* p){
  if(p->topo==NULL)return NULL;
  int*endereco=(int*)malloc(sizeof(int));
  pilha_pop2(p,endereco);
  return endereco;
}
}

Boolean pilha_pop2(Pilha* p, int* end){
  if(p->topo==NULL)return false;
  No*aux;
  aux=p->topo;
  p->topo=p->topo->prox;
  *endereco=aux->dado;
  free(aux);
  p->qtde--;
  return true;
}


 void pilha_imprimir1(Pilha* p){
     No* aux;
     while(p->topo!=NULL){
         aux=p->topo;
         printf("%d",aux->dado);
         p->topo=p->topo->prox;
     }
  }

int pilha_posicao(Pilha* p, int elemento){
  No*aux;
  int pos=0;
  while (p->topo!=NULL) {
    aux=p->topo;
    if(aux==elemento){
      return pos;
    }
    p->topo=p->topo->prox;
    pos ++;
  }
}

int pilha_tamanho(Pilha* p){
  if(p->topo==NULL)return 0;
  No*aux;
  int tam=0;
  aux=p->topo;
  p->topo=p->topo->prox;
  tam++;
  return tam;
}

int pilha_pushAll(Pilha* p, int* vetor, int tam){
  /**
 * Insere todos os elementos do vetor <vetor> na pilha <p>
 * @param p: Endereço da Pilha.
 * @param vetor: Endereço do vetor
 * @param tam: tamanho do <vetor>
 * @return quantidade de elementos inseridos na pilha <p>
 */
}

 Pilha* pilha_inverter(Pilha* p){
     Pilha* novaPilha = pilha_criar();
     No* aux = p->topo;

     while(aux != NULL){
         pilha_push(novaPilha, aux->dado);
         aux = aux->prox;
     }
     pilha_destruir(p);
     return novaPilha;
 }
 void pilha_inverter2(Pilha* p){

     No* novoTopo = NULL;
     No* aux;

     while(p->topo != NULL){
         //remover o aux da pilha p
         aux = p->topo;
         p->topo = p->topo->prox;
         //inserir no novo encadeamento
         aux->prox = novoTopo;
         novoTopo = aux;
     }
     p->topo = novoTopo;
 }
